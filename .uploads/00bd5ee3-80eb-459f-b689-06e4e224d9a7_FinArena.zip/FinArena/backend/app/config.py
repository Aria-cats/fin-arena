"""Fin Arena backend configuration: env loading & tunables."""
from __future__ import annotations

import os
from pathlib import Path

# akshare 部分接口用 tqdm 打进度条，污染服务日志，全局禁用
os.environ.setdefault("TQDM_DISABLE", "1")

from dotenv import load_dotenv

# backend/app/config.py -> app -> backend -> Fin Arena project root
_BACKEND_DIR = Path(__file__).resolve().parents[1]
_PROJECT_ROOT = _BACKEND_DIR.parent

# Project-root .env first (shared, contains the real ARK_API_KEY),
# then backend-local .env may override.
load_dotenv(_PROJECT_ROOT / ".env", override=False)
load_dotenv(_BACKEND_DIR / ".env", override=True)

ARK_API_URL: str = os.getenv("ARK_API_URL", "https://ark.cn-beijing.volces.com/api/coding/v3")
ARK_API_KEY: str = os.getenv("ARK_API_KEY", "")
ARK_MODEL: str = os.getenv("ARK_MODEL", "deepseek-v4-flash")

MAAS_API_URL: str = os.getenv("MAAS_API_URL", "")
MAAS_API_KEY: str = os.getenv("MAAS_API_KEY", "")
MAAS_MODEL: str = os.getenv("MAAS_MODEL", "")

def resolve_llm() -> tuple[str, str, str]:
    """返回 (base_url, api_key, model)。优先级：MAAS → ARK；自动修正 URL/KEY 写反的容错。"""
    maas_url = str(MAAS_API_URL or "").strip()
    maas_key = str(MAAS_API_KEY or "").strip()
    maas_model = str(MAAS_MODEL or "").strip()
    if maas_url and maas_key:
        u_is_url = maas_url.startswith("http://") or maas_url.startswith("https://")
        k_is_url = maas_key.startswith("http://") or maas_key.startswith("https://")
        if (not u_is_url) and k_is_url:
            maas_url, maas_key = maas_key, maas_url
            u_is_url, k_is_url = True, False
        if u_is_url and (not k_is_url) and maas_model:
            return (maas_url.rstrip("/"), maas_key, maas_model)
    # fallback ARK
    return (str(ARK_API_URL or "").rstrip("/"), str(ARK_API_KEY or ""), str(ARK_MODEL or "deepseek-v4-flash"))

LLM_BASE_URL, LLM_API_KEY, LLM_MODEL = resolve_llm()

DB_PATH: str = os.getenv("FINARENA_DB_PATH", str(_BACKEND_DIR / "finarena.db"))

# 预测对局结算的人工管理口令；为空时允许匿名结算（演示模式）
FORECAST_ADMIN_TOKEN: str = os.getenv("FORECAST_ADMIN_TOKEN", "")
DATA_DIR: str = os.getenv("FINARENA_DATA_DIR", str(_PROJECT_ROOT / "data"))

# Skill execution guardrails (design.md §2/§4)
SKILL_TIMEOUT: float = float(os.getenv("FINARENA_SKILL_TIMEOUT", "60"))  # seconds per skill call
TOOL_RESULT_MAX_CHARS: int = int(os.getenv("FINARENA_TOOL_RESULT_MAX_CHARS", "4000"))

# Agent loop guardrails (design.md §6)
AUTO_MAX_ROUNDS: int = int(os.getenv("FINARENA_AUTO_MAX_ROUNDS", "8"))
TEAM_MAX_ROUNDS: int = int(os.getenv("FINARENA_TEAM_MAX_ROUNDS", "5"))
CONTEXT_MESSAGES: int = int(os.getenv("FINARENA_CONTEXT_MESSAGES", "12"))

# LLM request timeout (per streaming round)
LLM_TIMEOUT: float = float(os.getenv("FINARENA_LLM_TIMEOUT", "180"))

FRONTEND_DIST = _PROJECT_ROOT / "frontend" / "dist"
PROJECT_ROOT: Path = _PROJECT_ROOT
BACKEND_DIR: Path = _BACKEND_DIR
